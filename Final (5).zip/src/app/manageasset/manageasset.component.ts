import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-manageasset',
  templateUrl: './manageasset.component.html',
  styleUrls: ['./manageasset.component.css']
})
export class ManageassetComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  assetId: any;
  assetName: any;
  assetType: any;
  description: any;
  location: any;
  searchTxt: any;
  assetIdErr = false;
  assetNameErr = false;
  assetTypeErr = false;
  locErr = false;
  result: any = [];
  currentPage = 1;
  isEditMode = false;
  result1: any = [];

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.showTable();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  showTable() {

    const getAllAssetDetailsSub = this._http.get(this.baseUrl + '/getAllAssetDetails/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing Asset');
    });
    this.subscriptions.add(getAllAssetDetailsSub);

  }

  addAsset(formsValue, formStatus) {
    this.assetIdErr = true;
    this.assetNameErr = true;
    this.assetTypeErr = true;
    this.locErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {

      const body = JSON.stringify({
        'assetId': formsValue.assetId,
        'assetName': formsValue.assetName,
        'assetType': formsValue.assetType,
        'description': formsValue.description,
        'location': formsValue.location
      });

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };

      const addAssetSub = this._http.post(this.baseUrl + '/addAsset/', body, httpOptions)
        .subscribe(data => {
          if (data === null) {
            alert('Asset ID: ' + this.assetId + ' has been already added in ' + formsValue.location);
          } else {
            alert('Successfully Added Asset');
          }
          this.reset();
          this.showTable();
        }, (err) => console.log('Error occurred in adding asset'));
      this.subscriptions.add(addAssetSub);
    }
  }

  deleteFieldValue(id) {
    const assetAssignedCheckSub = this._http.get(this.baseUrl + '/assetAssignedCheck/' + id.toString()).subscribe(data => {
      this.result1 = data;

      if (this.result1.empId === null || this.result1.empId === undefined || this.result1.empId === 'null') {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'text/plain',
            'Access-Control-Allow-Origin': '*'
          })
        };

        const res = confirm('Are you sure, you want to delete?');
        if (res) {
          const deleteAssetSub = this._http.delete(this.baseUrl + '/deleteAsset/' + id.toString(), httpOptions).subscribe(() => { });
           this.subscriptions.add(deleteAssetSub);
           this.result = this.result.filter(item => item.assetDetails.assetId !== id);
           this.reset();
           }

      } else {
        alert('Asset with id: ' + id + ' has been already allocated and in use. Kindly deallocate it before deleting.');
      }

    }, err => {
      console.log('Error Occured in deleting Asset');
    });
    this.subscriptions.add(assetAssignedCheckSub);
   
  }

  updateAsset(formsValue, formStatus) {

    this.assetIdErr = true;
    this.assetNameErr = true;
    this.assetTypeErr = true;
    this.locErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {

      const body = JSON.stringify({
        'assetId': formsValue.assetId,
        'assetName': formsValue.assetName,
        'assetType': formsValue.assetType,
        'description': formsValue.description,
        'location': formsValue.location
      });

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };

      const updateAssetDetailsSub = this._http.put(this.baseUrl + '/updateAssetDetails/', body, httpOptions)
        .subscribe(data => {
          alert('Successfully updated asset');
          this.reset();
          this.showTable();
          this.isEditMode = false;
        }, (err) => console.log('Error occurred in updating asset'));
      this.subscriptions.add(updateAssetDetailsSub);
    }

  }

  modifyAsset(aid: any, asstname: any, assttype: any, loc: any, desc: any) {
    this.isEditMode = true;
    this.assetId = aid;
    this.assetName = asstname;
    this.assetType = assttype;
    this.location = loc;
    this.description = desc;
  }

  reset() {
    this.assetId = '';
    this.assetName = '';
    this.assetType = '';
    this.location = '';
    this.searchTxt = '';
    this.description = '';
    this.assetIdErr = false;
    this.assetNameErr = false;
    this.assetTypeErr = false;
    this.locErr = false;
    this.isEditMode = false;
  }

  back() {
    this.router.navigate(['home']);
  }

}
