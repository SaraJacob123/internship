import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-firstpasswordchange',
  templateUrl: './firstpasswordchange.component.html',
  styleUrls: ['./firstpasswordchange.component.css']
})
export class FirstpasswordchangeComponent implements OnInit, OnDestroy {

  constructor(private myservice: AuthenticationService,
    private router: Router,
    private http: HttpClient) { }

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  email: any;
  password: any;
  cpass: any;
  CheckedPassword = false;
  passwordErr = false;
  cpassReqErr = false;
  cpassMatchErr = false;
  passPatternErr = false;

  ngOnInit() {
    this.email = this.myservice.getEmail();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  changePassword(formValue, formStatus) {

    if (formValue.cpass === '') {
      this.cpassReqErr = true;
    } else {
      this.cpassReqErr = false;
    }

    if (formValue.password === formValue.cpass) {
      this.CheckedPassword = true;
      this.cpassMatchErr = false;
    } else {
      this.cpassMatchErr = true;
      this.CheckedPassword = false;
    }

    this.passwordErr = true;
    this.passPatternErr = true;

    if (!formStatus || !this.CheckedPassword) {
      alert('Please fill the form with Required Data');
    } else {

      const body = JSON.stringify({
        'email': this.email,
        'password': formValue.password
      });

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'

        }
        )
      };

      const changePasswordSub = this.http.post(this.baseUrl + '/changepassword/', body, httpOptions).subscribe(data => {
        alert('Password Successfully Changed. Login using new password');
        this.router.navigate(['login']);
      }, (err) => {
        alert('Error occurred. Try after some time');
        this.router.navigate(['login']);
      });
      this.subscriptions.add(changePasswordSub);

    }

  }

  reset(formsValue) {
    this.password = '';
    this.cpass = '';
  }

}
