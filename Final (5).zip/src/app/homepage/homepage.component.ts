import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  email: any;
  user: any;

  constructor(private _authService: AuthenticationService) { }

  ngOnInit() {
    this.email = this._authService.getEmail();
    this.user = this._authService.getFirstName();
  }

}
