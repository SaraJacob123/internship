import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any;
  utype: any;
  currentPage = 1;
  hired: any;
  searchTxt: any;

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    const getAllUserSub = this._http.get(this.baseUrl + '/getAllUser/').subscribe(data => {
      this.result = data;
      this.utype = this.result.userType;
      if (this.utype === 'I') {
        this.result.userType = 'Intern';
      } else {
        this.result.userType = 'Employee';
      }
      this.hired = this.result.hired;

      if (this.hired === 'Y') {
        this.result.hired = 'Yes';
      } else {
        this.result.hired = 'No';
      }
    }, (err) => {
      console.log('Error Occured in listing user');
    });
    this.subscriptions.add(getAllUserSub);

  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  deleteFieldValue(id) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };

    const res = confirm('Are you sure, you want to delete?');
    if (res) {
      const deleteUserSub = this._http.delete(this.baseUrl + '/deleteUser/' + id.toString(), httpOptions).subscribe(() => { });
      this.result = this.result.filter(item => item.empId !== id);
      this.subscriptions.add(deleteUserSub);
    }
  }

  back() {
    this.router.navigate(['home']);
  }
}


