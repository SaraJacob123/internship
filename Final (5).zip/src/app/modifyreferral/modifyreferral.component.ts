import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-modifyreferral',
  templateUrl: './modifyreferral.component.html',
  styleUrls: ['./modifyreferral.component.css']
})
export class ModifyreferralComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  referrerId: any;
  referrerName: any;
  referrerEmail: any;
  id: any;
  studentName: any;
  studentEmail: any;
  status: any;
  interviewerId: any;
  interviewerName: any;
  interviewerEmail: any;
  comments: any;
  error: any;
  referrerIdClearErr = false;
  referrerNameClearErr = false;
  referrerEmailClearErr = false;
  studentNameClearErr = false;
  studentEmailClearErr = false;
  statusClearErr = false;
  interviewerIdClearErr = false;
  interviewerNameClearErr = false;
  interviewerEmailClearErr = false;
  commentsClearErr = false;
  result: any;
  employees: any = [];
  typeofUser: any;
  existingIntern: boolean;


  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };


  constructor(private router: Router,
    private _http: HttpClient,
    private _route: ActivatedRoute,
    private _authService: AuthenticationService) { }

  ngOnInit() {
    this.typeofUser = this._authService.getTypeofUser();
    this._route.paramMap.switchMap((params: ParamMap) => this.id = params.get('id')).subscribe();


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json;charset=UTF-8',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };


    const getCandidateSub = this._http.get(this.baseUrl + '/getCandidate/' + this.id, httpOptions).subscribe(data => {
      this.result = data;

      this.referrerId = this.result.referrerId;
      this.referrerName = this.result.referrerName;
      this.referrerEmail = this.result.referrerEmail;
      this.studentName = this.result.candName;
      this.studentEmail = this.result.candEmail;
      this.status = this.result.assignment;
      this.interviewerId = this.result.interviewerId;
      this.interviewerName = this.result.interviewerName;
      this.interviewerEmail = this.result.interviewerEmail;

    },
      error => this.error = error
    );
    this.subscriptions.add(getCandidateSub);




  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }



  reset(formsValue) {
    this.referrerId = '';
    this.referrerName = '';
    this.referrerEmail = '';
    this.studentName = '';
    this.studentEmail = '';
    this.status = '';
    this.interviewerId = '';
    this.interviewerName = '';
    this.interviewerEmail = '';
    this.referrerIdClearErr = false;
    this.referrerNameClearErr = false;
    this.referrerEmailClearErr = false;
    this.studentNameClearErr = false;
    this.studentEmailClearErr = false;
    this.statusClearErr = false;
    this.interviewerIdClearErr = false;
    this.interviewerNameClearErr = false;
    this.interviewerEmailClearErr = false;
    this.commentsClearErr = false;
  }

  modifyReferral(formValue: any, formStatus: any) {

    this.referrerIdClearErr = true;
    this.referrerNameClearErr = true;
    this.referrerEmailClearErr = true;
    this.studentNameClearErr = true;
    this.studentEmailClearErr = true;
    this.statusClearErr = true;
    this.interviewerIdClearErr = true;
    this.interviewerNameClearErr = true;
    this.interviewerEmailClearErr = true;
    this.commentsClearErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      let mainBody;
      mainBody = JSON.stringify({
        'candID': this.id,
        'candName': formValue.studentName,
        'candEmail': formValue.studentEmail,
        'referrerId': formValue.referrerId,
        'referrerName': formValue.referrerName,
        'referrerEmail': formValue.referrerEmail,
        'interviewerId': formValue.interviewerId,
        'interviewerName': formValue.interviewerName,
        'interviewerEmail': formValue.interviewerEmail,
        'assignment': formValue.status,
        'comments': formValue.comments
      });


      const modifyReferral = this._http.put(this.baseUrl + '/updateCandidate/', mainBody, this.httpOptions)
        .subscribe(data => {

          alert('Sucessfull');
          this.referrerId = '';
          this.referrerName = '';
          this.referrerEmail = '';
          this.studentName = '';
          this.studentEmail = '';
          this.status = '';
          this.comments = '';
          this.interviewerId = '';
          this.interviewerName = '';
          this.interviewerEmail = '';
          this.referrerIdClearErr = false;
          this.referrerNameClearErr = false;
          this.referrerEmailClearErr = false;
          this.studentNameClearErr = false;
          this.studentEmailClearErr = false;
          this.statusClearErr = false;
          this.interviewerIdClearErr = false;
          this.interviewerNameClearErr = false;
          this.interviewerEmailClearErr = false;
          this.commentsClearErr = false;

        }, (err) => {
          console.log(err.message);
          alert('Error occurred');
        }
        );
      this.subscriptions.add(modifyReferral);

    }
  }

  back() {
    this.router.navigate(['home']);
  }

}
