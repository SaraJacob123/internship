import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyreferralComponent } from './modifyreferral.component';

describe('ModifyreferralComponent', () => {
  let component: ModifyreferralComponent;
  let fixture: ComponentFixture<ModifyreferralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyreferralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyreferralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
