import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css']
})
export class UpdateProjectComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  projectId: any;
  projectName: any;
  manager: any;
  architect: any;
  status: any;
  type: any;
  result: any;
  internId: any;
  firstName: any;
  lastName: any;
  startDt: any;
  endDt: any;
  skills: any;
  addedResources: any = [];
  allDropDownValues: any = [];
  managers: any = [];
  architects: any = [];
  actstartDt: any;
  actendDt: any;
  planstartDt: any;
  planendDt: any;
  actPoc: any;
  comments: any;
  description: any;
  pnameClearErr = false;
  managerClearErr = false;
  architectClearErr = false;
  asDateClearErr = false;
  aeDateClearErr = false;
  invalidADateErr = false;
  plansDateClearErr = false;
  planeDateClearErr = false;
  invalidPDateErr = false;
  statusClearErr = false;
  typeClearErr = false;
  pocClearErr = false;
  desTypeErr = false;
  name: any;
  typeofUser: any;
  id: any;
 intern:any;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router,
    private _http: HttpClient,
    private _route: ActivatedRoute,
    private _authService: AuthenticationService) { }

  ngOnInit() {
    this.internDetails();
    this.employeeDetails();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  internDetails() {
    const getAllInternsSub = this._http.get(this.baseUrl + '/getAllInternsForProjects/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing interns');
    });
    this.subscriptions.add(getAllInternsSub);
  }

  employeeDetails() {
    const getAllUserSub = this._http.get(this.baseUrl + '/getAllUser/')
      .subscribe(dataDropDown => {
        this.allDropDownValues = dataDropDown;

        for (const value of this.allDropDownValues) {
          if (value.userType === 'Employee') {
            this.managers.push({'empId': value.empId,'firstName': value.firstName, 'lastName': value.lastName });
            this.architects.push({'empId': value.empId,'firstName': value.firstName, 'lastName': value.lastName });
          }
        }

      });
    this.subscriptions.add(getAllUserSub);
  }

  onManagerChange(selectedManager: any) {
    this.manager = selectedManager;    
   }
 
   onArchitectChange(selectedArchitect: any) {
    this.architect = selectedArchitect;
   }

  updateProject(formValue: any, formStatus: any) {

    this.pnameClearErr = true;
    this.managerClearErr = true;
    this.architectClearErr = true;
    this.asDateClearErr = true;
    this.aeDateClearErr = true;
    this.plansDateClearErr = true;
    this.planeDateClearErr = true;
    this.statusClearErr = true;
    this.typeClearErr = true;
    this.pocClearErr = true;
    this.desTypeErr = true;
 
    

    if (formValue.actstartDt > formValue.actendDt) {
      this.invalidADateErr = true;
    } else {
      this.invalidADateErr = false;
    }

    if (formValue.planstartDt > formValue.planendDt) {
      this.invalidPDateErr = true;
    } else {
      this.invalidPDateErr = false;
    }

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      this.manager = formValue.manager;
      this.architect = formValue.architect;
      this.actstartDt = formValue.actstartDt;
      this.actendDt = formValue.actendDt;
      this.planstartDt = formValue.planstartDt;
      this.planendDt = formValue.planendDt;
      this.status = formValue.status;
      this.type = formValue.type;
      this.actPoc = formValue.actPoc;
      this.comments = formValue.comments;
      this.description = formValue.description;
      const projectBody = JSON.stringify({
    
        
        'projectName': formValue.projectName,
        'description': this.description,
        'projectType': this.type,
        'accountPoc': this.actPoc,
        'status': this.status,
        'comments': this.comments,
        'projectManager': this.manager,
        'projectArchitect': this.architect,
        'intern': this.firstName,
        'internId': this.internId,
        'plannedStartDate': this.planstartDt,
        'plannedEndtDate': this.planendDt,
        'actualstartDate': this.actstartDt,
        'actualendDate': this.actendDt
      });

      this._http.post('http://192.168.136.80:8080/updateProject/', projectBody, this.httpOptions)
        .subscribe(data => {
          alert('Update project successfully');
          this.reset();
        }, (err) => {
          console.log('Error occured in assigning Project: ' + err.message);

        });
    }

  }

  deleteSelectedInterns(IntId :any,intern: any,index :number) {
    this.addedResources.splice(index, 1);
    this.intern = '';
}

addIntern(intId: any, fName: any, lName: any, sDate: any, eDate: any, skillsIntern: any) {
  if (this.addedResources.findIndex(x => x.internId === intId) < 0) {
    this.addedResources.push({
      internId: intId, firstName: fName, lastName: lName, startDate: sDate, endDate: eDate, skills: skillsIntern
    });
  } else {
    alert(fName + ' ' + lName + '' + ' is already selected');
  }
}

  reset() {
    this.projectId = '';
    this.projectName = '';
    this.description = '';
    this.manager = '';
    this.architect = '';
    this.actstartDt = '';
    this.actendDt = '';
    this.planstartDt = '';
    this.planendDt = '';
    this.status = '';
    this.type = '';
    this.actPoc = '';
    this.comments = '';
    this.desTypeErr = false;
    this.pnameClearErr = false;
    this.managerClearErr = false;
    this.architectClearErr = false;
    this.asDateClearErr = false;
    this.aeDateClearErr = false;
    this.invalidADateErr = false;
    this.plansDateClearErr = false;
    this.planeDateClearErr = false;
    this.invalidPDateErr = false;
    this.statusClearErr = false;
    this.typeClearErr = false;
    this.pocClearErr = false;
    this.addedResources = [];
  }




  back() {
    this.router.navigate(['home']);
  }


}
