import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchPipe implements PipeTransform {

  transform(values: any, searchText: string): any[] {

    if (values === undefined) {
      return values;
    }
    if (searchText === undefined) {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined && value.firstName !== undefined && value.lastName !== undefined && value.empId !== undefined) {
        return value.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
          value.empId.toLowerCase().includes(searchText.toLowerCase()) || value.lastName.toLowerCase().includes(searchText.toLowerCase());
      } else if (value !== undefined && value.firstName !== undefined && value.lastName !== undefined && value.internId !== undefined) {
        return value.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
          value.internId.toLowerCase().includes(
            searchText.toLowerCase()) || value.lastName.toLowerCase().includes(searchText.toLowerCase()
            );
      } else if (value !== undefined && value.seatId !== undefined && value.systemId !== undefined && value.location !== undefined) {
        return value.seatId.toLowerCase().includes(searchText.toLowerCase()) ||
          value.systemId.toLowerCase().includes(
            searchText.toLowerCase()) || value.location.toLowerCase().includes(searchText.toLowerCase()
            );
      } else if (value !== undefined && value.empId === null &&
        value.assetId !== undefined && value.assetName !== undefined &&
        value.assetType !== undefined && value.location !== undefined) {
        return String(value.assetId).includes(searchText) ||
          value.assetName.toLowerCase().includes(
            searchText.toLowerCase()) || value.assetType.toLowerCase().includes(
              searchText.toLowerCase()) || value.location.toLowerCase().includes(
                searchText.toLowerCase());
      } else if (value !== undefined && value.seatId !== undefined && value.empId !== undefined && value.location !== undefined) {
        return value.seatId.toLowerCase().includes(searchText.toLowerCase()) ||
          value.empId.toLowerCase().includes(searchText.toLowerCase()) || value.location.toLowerCase().includes(searchText.toLowerCase());
      } else if (value !== undefined &&
        value.empId !== undefined &&
        value.assetId !== undefined &&
        value.assetName !== undefined &&
        value.assetType !== undefined &&
        value.location !== undefined) {
        return value.empId.toLowerCase().includes(
          searchText.toLowerCase()) || String(value.assetId).includes(searchText) ||
          value.assetName.toLowerCase().includes(
            searchText.toLowerCase()) || value.assetType.toLowerCase().includes(
              searchText.toLowerCase()) || value.location.toLowerCase().includes(
                searchText.toLowerCase());
      } else {
        return values;
      }

    });
  }

}
