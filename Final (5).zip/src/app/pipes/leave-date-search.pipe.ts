import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'leaveDateSearchFilter'
})
export class LeaveDateSearchPipe implements PipeTransform {

  transform(values: any, fromDt: string, toDt: string): any[] {

    if (values === undefined) {
      return values;
    }

    if (fromDt === undefined && toDt === undefined) {
      return values;
    }

    if (fromDt === '' && toDt === '') {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined &&
        value.leaveRequest.fromDate !== undefined &&
        (fromDt !== undefined || fromDt !== '') &&
        (toDt === undefined || toDt === '')) {
        return Date.parse(value.leaveRequest.fromDate) + 19800000 >= Date.parse(fromDt);
      } else if (value !== undefined &&
        value.leaveRequest.toDate !== undefined &&
        (toDt !== undefined || toDt !== '') &&
        (fromDt === undefined || fromDt === '')) {
        return Date.parse(value.leaveRequest.toDate) - 19800000 <= Date.parse(toDt);
      } else if (value !== undefined &&
        value.leaveRequest.fromDate !== undefined &&
        value.leaveRequest.toDate !== undefined &&
        (fromDt !== undefined && fromDt !== '') &&
        (toDt !== undefined && toDt !== '')) {
        return (Date.parse(value.leaveRequest.toDate) - 19800000 <= Date.parse(toDt)) &&
          (Date.parse(value.leaveRequest.fromDate) + 19800000 >= Date.parse(fromDt));
      } else {
        return values;
      }
    });
  }

}
