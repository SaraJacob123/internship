import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusFilter'
})
export class StatusSearchPipe implements PipeTransform {

  transform(values: any, searchText: string): any[] {

    if (values === undefined) {
      return values;
    }
    if (searchText === undefined) {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined && value.status !== undefined) {
        return value.status.toLowerCase().includes(searchText.toLowerCase());
      } else {
        return values;
      }
    });
  }

}
