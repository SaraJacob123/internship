import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'assetSearchFilter'
})
export class AssetSearchPipe implements PipeTransform {

  transform(values: any, searchText: string): any[] {

    if (values === undefined) {
      return values;
    }
    if (searchText === undefined) {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined && value.assetDetails.empId !== undefined && value.assetDetails.empId !== null &&
        value.firstName !== undefined && value.firstName !== null &&
        value.lastName !== undefined && value.lastName !== null &&
        value.assetDetails.assetId !== undefined && value.assetDetails.assetName !== undefined &&
        value.assetDetails.assetType !== undefined && value.assetDetails.location !== undefined) {
          return String(value.assetDetails.empId).includes(searchText) ||
            value.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
            value.lastName.toLowerCase().includes(searchText.toLowerCase()) ||
            String(value.assetDetails.assetId).includes(searchText) ||
            value.assetDetails.assetName.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.assetType.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.location.toLowerCase().includes(searchText.toLowerCase());
      } else if (value !== undefined && value.assetDetails.empId === null &&
        value.firstName === null && value.lastName === null &&
        value.assetDetails.assetId !== undefined && value.assetDetails.assetName !== undefined &&
        value.assetDetails.assetType !== undefined && value.assetDetails.location !== undefined) {
          return String(value.assetDetails.assetId).includes(searchText) ||
            value.assetDetails.assetName.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.assetType.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.location.toLowerCase().includes(searchText.toLowerCase());
      } else if (value !== undefined && value.assetDetails.assetId !== undefined && value.assetDetails.assetName !== undefined &&
        value.assetDetails.assetType !== undefined && value.assetDetails.location !== undefined) {
          return String(value.assetDetails.assetId).includes(searchText) ||
            value.assetDetails.assetName.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.assetType.toLowerCase().includes(searchText.toLowerCase()) ||
            value.assetDetails.location.toLowerCase().includes(searchText.toLowerCase());
      } else {
        return values;
      }

    });
  }

}
