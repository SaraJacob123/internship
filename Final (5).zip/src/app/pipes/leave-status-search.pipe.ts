import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'leaveStatusFilter'
})
export class LeaveStatusSearchPipe implements PipeTransform {

  transform(values: any, searchText: string): any[] {

    if (values === undefined) {
      return values;
    }

    if (searchText === undefined) {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined && value.leaveRequest.status !== undefined) {
        return value.leaveRequest.status.toLowerCase().includes(searchText.toLowerCase());
      } else {
        return values;
      }
    });
  }

}
