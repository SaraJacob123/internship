import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'seatSearchFilter'
})
export class SeatSearchPipe implements PipeTransform {

  transform(values: any, searchText: string): any[] {

    if (values === undefined) {
      return values;
    }
    if (searchText === undefined) {
      return values;
    }

    return values.filter(function (value) {
      if (value !== undefined && value.seat.empId !== undefined &&
        value.firstName !== undefined && value.lastName !== undefined &&
        value.seat.seatId !== undefined && value.seat.location !== undefined) {
          return String(value.seat.empId).includes(searchText) ||
            value.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
            value.lastName.toLowerCase().includes(searchText.toLowerCase()) ||
            String(value.seat.seatId).includes(searchText) ||
            value.seat.location.toLowerCase().includes(searchText.toLowerCase());
      } else {
        return values;
      }

    });
  }

}
