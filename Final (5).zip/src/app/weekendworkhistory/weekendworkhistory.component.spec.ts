import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekendworkhistoryComponent } from './weekendworkhistory.component';

describe('WeekendworkhistoryComponent', () => {
  let component: WeekendworkhistoryComponent;
  let fixture: ComponentFixture<WeekendworkhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekendworkhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekendworkhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
