import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-referral',
  templateUrl: './referral.component.html',
  styleUrls: ['./referral.component.css']
})
export class ReferralComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  referrerId: any;
  referrerName: any;
  referrerEmail: any;
  id: any;
  studentName: any;
  studentEmail: any;
  status: any;
  interviewerId: any;
  interviewerName: any;
  interviewerEmail: any;
  comments: any;
  error: any;
  referrerIdClearErr = false;
  referrerNameClearErr = false;
  referrerEmailClearErr = false;
  studentNameClearErr = false;
  studentEmailClearErr = false;
  statusClearErr = false;
  interviewerIdClearErr = false;
  interviewerNameClearErr = false;
  interviewerEmailClearErr = false;
  commentsClearErr = false;
  result: any;
  employees: any = [];
  typeofUser: any;
  existingIntern: boolean;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router,
    private _http: HttpClient,
    private _route: ActivatedRoute,
    private _authService: AuthenticationService) { }

  ngOnInit() {
    this.typeofUser = this._authService.getTypeofUser();

  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }



  reset(formsValue) {
    this.referrerId = '';
    this.referrerName = '';
    this.referrerEmail = '';
    this.studentName = '';
    this.studentEmail = '';
    this.status = '';
    this.interviewerId = '';
    this.interviewerName = '';
    this.interviewerEmail = '';
    this.referrerIdClearErr = false;
    this.referrerNameClearErr = false;
    this.referrerEmailClearErr = false;
    this.studentNameClearErr = false;
    this.studentEmailClearErr = false;
    this.statusClearErr = false;
    this.interviewerIdClearErr = false;
    this.interviewerNameClearErr = false;
    this.interviewerEmailClearErr = false;
    this.commentsClearErr = false;
  }

  addReferral(formValue: any, formStatus: any) {

    this.referrerIdClearErr = true;
    this.referrerNameClearErr = true;
    this.referrerEmailClearErr = true;
    this.studentNameClearErr = true;
    this.studentEmailClearErr = true;
    this.statusClearErr = true;
    this.interviewerIdClearErr = true;
    this.interviewerNameClearErr = true;
    this.interviewerEmailClearErr = true;
    this.commentsClearErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      let mainBody;
      mainBody = JSON.stringify({
        'candName': formValue.studentName,
        'candEmail': formValue.studentEmail,
        'referrerId': formValue.referrerId,
        'referrerName': formValue.referrerName,
        'referrerEmail': formValue.referrerEmail,
        'techLeadId': formValue.interviewerId,
        'techLead': formValue.interviewerName,
        'techLeadEmail': formValue.interviewerEmail,
        'assignment': formValue.status,
        'comments': formValue.comments
      });

      const addReferral = this._http.post(this.baseUrl + '/registerCandidate/', mainBody, this.httpOptions)
        .subscribe(data => {

          alert('Sucessfull');
          this.referrerId = '';
          this.referrerName = '';
          this.referrerEmail = '';
          this.studentName = '';
          this.studentEmail = '';
          this.status = '';
          this.comments = '';
          this.interviewerId = '';
          this.interviewerName = '';
          this.interviewerEmail = '';
          this.referrerIdClearErr = false;
          this.referrerNameClearErr = false;
          this.referrerEmailClearErr = false;
          this.studentNameClearErr = false;
          this.studentEmailClearErr = false;
          this.statusClearErr = false;
          this.interviewerIdClearErr = false;
          this.interviewerNameClearErr = false;
          this.interviewerEmailClearErr = false;
          this.commentsClearErr = false;

        }, (err) => {
          console.log(err.message);
          alert('Error occurred');
        }
        );
      this.subscriptions.add(addReferral);

    }
  }

  back() {
    this.router.navigate(['home']);
  }

}





