import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() email: any;
  loggedinUser: any;
  showUser: boolean;
  isExistingIntern: any;
  showModifyIntern: boolean;

  constructor(private router: Router, private _authService: AuthenticationService) { }

  ngOnInit() {

    this.loggedinUser = this._authService.getuser();

    if (this.loggedinUser === 'I') {
      this.showUser = true;
    } else {
      this.showUser = false;

    }

    this.isExistingIntern = this._authService.getTypeofUser();
    if (this.isExistingIntern === 'EXISTING_INTERN') {
      this.showModifyIntern = true;
    } else {
      this.showModifyIntern = false;
    }

  }

  logout() {
    this._authService.setLoggedInStatus(false);
    this._authService.setEmail('');
    this.router.navigate(['login']);
  }
}
