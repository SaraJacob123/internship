import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-allocate-asset',
  templateUrl: './allocate-asset.component.html',
  styleUrls: ['./allocate-asset.component.css']
})
export class AllocateAssetComponent implements OnInit, OnDestroy {

  constructor(private _http: HttpClient, private router: Router) { }

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  internIdError = false;
  internId: any;
  result: any;
  interns: any = [];
  searchTxt: any;
  currentPage = 1;

  ngOnInit() {
    this.showTable();
    const getAllInternsSub = this._http.get(this.baseUrl + '/getAllInterns/').subscribe(
      dataDropDown => {
        this.interns = dataDropDown;
      }, (err) => {
        console.log('Error Occured in listing non assigned interns');
      }
    );
    this.subscriptions.add(getAllInternsSub);
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  showTable() {

    const getAllAssetDetailsSub = this._http.get(this.baseUrl + '/getAllAssetDetails/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing Asset');
    });
    this.subscriptions.add(getAllAssetDetailsSub);

  }

  allocateAsset(formsValue, formStatus, assetId) {

    this.internIdError = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };

      const allocateAssetSub = this._http.put(this.baseUrl + '/allocateAsset/' + assetId + '/' + formsValue.internId, httpOptions)
        .subscribe(data => {
          alert('Successfully allocated asset');
          this.showTable();
          this.reset();
        }, err => {
          console.log('Error occurred in allocating seat');
        });
      this.subscriptions.add(allocateAssetSub);
    }

  }

  deAllocateAsset(assetId: any, empId: any) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      })
    };

    const res = confirm('Are you sure, you want to de-allocate?');
    if (res) {
      const deAllocateAssetSub = this._http.put(this.baseUrl + '/deAllocateAsset/' + assetId + '/' + empId, httpOptions)
        .subscribe(data => {
          alert('Successfully de-allocated asset');
          this.reset();
          this.showTable();
        }, (err) => {
          console.log('Error occurred in de-allocating asset');
        });
      this.subscriptions.add(deAllocateAssetSub);
    }

  }

  reset() {
    this.internId = '';
    this.internIdError = false;
    this.searchTxt = '';
  }

  back() {
    this.router.navigate(['home']);
  }

}



