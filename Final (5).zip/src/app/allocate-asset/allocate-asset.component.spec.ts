import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocateAssetComponent } from './allocate-asset.component';

describe('AllocateAssetComponent', () => {
  let component: AllocateAssetComponent;
  let fixture: ComponentFixture<AllocateAssetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocateAssetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocateAssetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
