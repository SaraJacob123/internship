import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-referrallist',
  templateUrl: './referrallist.component.html',
  styleUrls: ['./referrallist.component.css']
})
export class ReferrallistComponent implements OnInit , OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any = [];
  firstName: any;
  lastName: any;
  currentPage = 1;
  searchText: any;
  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    this._http.get(this.baseUrl + '/getAllCandidates/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in Listing Candidates');
    });

  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }


  deleteFieldValue(id) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };

    const res = confirm('Are you sure, you want to delete?');
    if (res) {
      const deleteCandidateSub = this._http.delete(this.baseUrl + '/deleteCandidate/' + id.toString(), httpOptions).subscribe(() => { });
      this.result = this.result.filter(item => item.candID !== id);
      this.subscriptions.add(deleteCandidateSub);
    }

  }

  back() {
    this.router.navigate(['home']);
  }

}



