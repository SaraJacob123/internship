import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  userType: any;
  email: any;
  eId: any;
  firstName: any;
  lastName: any;
  ECidError = false;
  fnameclearErr = false;
  lastNameErr = false;
  emailErr = false;
  utypeErr = false;
  isEmailChecked = false;

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {
    this.email = '';
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  generateEmail() {
    if (this.eId === undefined) {
      this.email = '';
    } else {
      this.email = this.eId + '@ust-global.com';
    }
  }

  addUser(formsValue, formStatus) {

    this.ECidError = true;
    this.fnameclearErr = true;
    this.lastNameErr = true;
    this.emailErr = true;
    this.isEmailChecked = true;
    this.utypeErr = true;

    if (formsValue.eId && formsValue.eId.length > 0) {
      this.isEmailChecked = false;
    }

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {

      this.userType = formsValue.userType;

      const body = JSON.stringify({
        'userType': this.userType,
        'empId': formsValue.eId,
        'firstName': formsValue.firstName,
        'lastName': formsValue.lastName,
        'email': formsValue.email,
        'password': formsValue.password,
        'status': 'P'
      });

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };

      const addUserSub = this.http.post(this.baseUrl + '/addUser/', body, httpOptions)
        .subscribe(data => {
          if (data === null) {
            alert('User Already Exists');
          } else {
            alert('Succesfully Added User');
            this.eId = '';
            this.email = '';
            this.userType = '';
            this.firstName = '';
            this.lastName = '';
            this.ECidError = false;
            this.fnameclearErr = false;
            this.lastNameErr = false;
            this.emailErr = false;
            this.utypeErr = false;
          }
        }, (err) => console.log('Error occurred in adding user'));

      this.subscriptions.add(addUserSub);
    }

  }

  reset(formsValue) {
    this.eId = '';
    this.email = '';
    this.userType = '';
    this.firstName = '';
    this.lastName = '';
    this.ECidError = false;
    this.fnameclearErr = false;
    this.lastNameErr = false;
    this.emailErr = false;
    this.utypeErr = false;
  }

  back() {
    this.router.navigate(['home']);
  }

}
