import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-addintern',
  templateUrl: './addintern.component.html',
  styleUrls: ['./addintern.component.css']
})
export class AddinternComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  email: any;
  firstname: any;
  lastname: any;
  cid: any;
  allDropDownValues: any = [];
  skills: any = [];
  branches: any = [];
  branch: any;
  selectedSkills: any = [];
  proficiency: any;
  preferred: any;
  skill: any;
  duration: any;
  startDt: any;
  endDt: any;
  mobile: any;
  accessCardNo: any;
  qualification: any;
  specialization: any;
  college: any;
  cEmailId: any;
  Backpaper: any;
  cgpa: any;
  year: any;
  pdfFile: any;
  selskillid: any;
  selPro: any;
  selPref: any;
  selproficiency: any;
  selpreferred: any;
  qualifications: any = [];
  result: any;
  ongoing: any;
  httpOptions: any;
  location: any;
  comments: any;
  durClearErr = false;
  sDateClearErr = false;
  eDateClearErr = false;
  accessnoClearErr = false;
  mobileclearErr = false;
  qualificationSelErr = false;
  BranchSelErr = false;
  OngoingClearErr = false;
  CollegeClearErr = false;
  coemailErr = false;
  backpapervalidErr = false;
  cgpavalidErr = false;
  YofErr = false;
  collegelettervalidErr = false;
  invalidDateErr = false;
  locationvalidErr = false;

  constructor(private router: Router,
    private _http: HttpClient,
    private _authService: AuthenticationService) { }

  ngOnInit() {

    this.email = this._authService.getEmail();

    const emailBody = JSON.stringify({
      email: this.email

    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };

    const getEmailUserSub = this._http.post(this.baseUrl + '/getEmailUser/', emailBody, this.httpOptions)
      .subscribe(data => {
        this.result = data;
        if (data[0] !== null) {
          this.firstname = data[0].firstName;
          this.lastname = data[0].lastName;
          this.cid = data[0].empId;
        }

        const getAllOptionsSub = this._http.get(this.baseUrl + '/getAllOptions/')
          .subscribe(dataDropDown => {
            this.allDropDownValues = dataDropDown;
            for (const value of this.allDropDownValues) {
              if (value.optionType === 'skill') {
                this.skills.push({ 'skillId': value.optionCode, 'description': value.optionDesc });
              } else if (value.optionType === 'qualification') {
                this.qualifications.push({ 'qualificationId': value.optionCode, 'description': value.optionDesc });
              } else if (value.optionType === 'branch') {
                this.branches.push({ 'branchId': value.optionCode, 'description': value.optionDesc });
              }
            }
          }, (err) => {
            console.log('Error occurred in getting drop down values');
          });
        this.subscriptions.add(getAllOptionsSub);
      }, (err) => {
        console.log('Error occured in getting Email');
      });
    this.subscriptions.add(getEmailUserSub);

  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  setOnGoing(onGoing: any) {
    this.ongoing = onGoing;
  }

  back() {
    this.router.navigate(['home']);
  }

  fileChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      const file: File = fileList[0];
      this.pdfFile = file;
      this.collegelettervalidErr = false;
    } else {
      this.pdfFile = undefined;
      this.collegelettervalidErr = true;
    }
  }

  addIntern(formValue: any, formStatus: any) {

    this.durClearErr = true;
    this.sDateClearErr = true;
    this.eDateClearErr = true;
    this.accessnoClearErr = true;
    this.mobileclearErr = true;
    this.qualificationSelErr = true;
    this.BranchSelErr = true;
    this.OngoingClearErr = true;
    this.CollegeClearErr = true;
    this.coemailErr = true;
    this.backpapervalidErr = true;
    this.cgpavalidErr = true;
    this.YofErr = true;
    this.locationvalidErr = true;

    if (formValue.startDt > formValue.endDt) {
      this.invalidDateErr = true;
    } else {
      this.invalidDateErr = false;
    }

    if (this.pdfFile === undefined) {
      this.collegelettervalidErr = true;
    } else {
      this.collegelettervalidErr = false;
    }

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      const mainBody = JSON.stringify({
        'empId': formValue.cid,
        'firstName': formValue.firstname,
        'lastName': formValue.lastname,
        'email': formValue.email,
        'duration': formValue.duration,
        'startDate': formValue.startDt,
        'endDate': formValue.endDt,
        'mobile': formValue.mobile,
        'accessCardNo': formValue.accessCardNo,
        'qualificationId': formValue.qualification,
        'branchId': formValue.branch,
        'college': formValue.college,
        'coordinatorEmail': formValue.cEmailId,
        'ongoing': formValue.ongoing,
        'approvalLetter': null,
        'backPaper': formValue.Backpaper,
        'cgpa': formValue.CGPA,
        'yearOfPass': formValue.Year,
        'location': formValue.location,
        'comments': formValue.comments
      });

      const addInternSub = this._http.post(this.baseUrl + '/addIntern/', mainBody, this.httpOptions)
        .subscribe(data => {

          if (this.pdfFile !== undefined) {
            const formData = new FormData();
            formData.append('empId', formValue.cid);
            formData.append('file', this.pdfFile);

            const uploadLetterSub = this._http.post(this.baseUrl + '/uploadLetter/file', formData, { responseType: 'text' })
              .subscribe(() => {
                console.log('File uploaded successfully');
              }, (err) => {
                console.log('Error occured in uploading file : ' + err.message);
              });

            this.subscriptions.add(uploadLetterSub);

          }

          for (let i = 0; i < this.selectedSkills.length; i++) {
            this.selskillid = this.selectedSkills[i].skillId;
            this.selPro = this.selectedSkills[i].proficiency;
            this.selPref = this.selectedSkills[i].preferred;

            if (this.selPro === 'Expert') {
              this.selproficiency = 'E';
            } else if (this.selPro === 'Intermediate') {
              this.selproficiency = 'I';
            } else if (this.selPro === 'Advanced') {
              this.selproficiency = 'A';
            } else {
              this.selproficiency = 'B';
            }

            if (this.selPref === 'Yes') {
              this.selpreferred = 'Y';
            } else {
              this.selpreferred = 'N';
            }

            const skillBody = JSON.stringify({
              'skillId': this.selskillid,
              'proficiency': this.selproficiency,
              'preferred': this.selpreferred,
              'other': null,
              'internId': formValue.cid
            });

            const addInternSkillSub = this._http.post(this.baseUrl + '/addInternSkill/', skillBody, this.httpOptions)
              .subscribe(() => {
                console.log('Skill added successfully');
              }, (err) => {
                console.log('Error occured in adding skill: ' + err.mssage);
              });

            this.subscriptions.add(addInternSkillSub);

          }

          alert('Intern added successfully');
        }, (err) => {
          alert('Error occurred in adding intern');
        }
        );
      this.subscriptions.add(addInternSub);
    }
  }

  addSkill(formVal: any, skillName: any) {

    if (this.selectedSkills.findIndex(x => x.skillId === formVal.skill) < 0) {
      this.selectedSkills.push({
        skillId: formVal.skill,
        skill: skillName,
        proficiency: formVal.proficiency,
        preferred: formVal.preferred
      });
    } else {
      alert(skillName + ' is already added to selected skills');
    }
    this.proficiency = '';
    this.preferred = '';
    this.skill = '';

  }

  deleteSkill(skillId: any, skill: any, index: number) {
    this.selectedSkills.splice(index, 1);
    this.skill = '';
  }

  reset() {
    this.duration = '';
    this.startDt = '';
    this.endDt = '';
    this.mobile = '';
    this.accessCardNo = '';
    this.qualification = '';
    this.specialization = '';
    this.branch = '';
    this.ongoing = '';
    this.cEmailId = '';
    this.Backpaper = '';
    this.cgpa = '';
    this.year = '';
    this.college = '';
    this.comments = '';
    this.location = '';
    this.durClearErr = false;
    this.sDateClearErr = false;
    this.eDateClearErr = false;
    this.accessnoClearErr = false;
    this.mobileclearErr = false;
    this.qualificationSelErr = false;
    this.BranchSelErr = false;
    this.OngoingClearErr = false;
    this.CollegeClearErr = false;
    this.coemailErr = false;
    this.backpapervalidErr = false;
    this.cgpavalidErr = false;
    this.YofErr = false;
    this.collegelettervalidErr = false;
    this.locationvalidErr = false;
    this.selectedSkills = [];
    this.skill = '';
  }

}
