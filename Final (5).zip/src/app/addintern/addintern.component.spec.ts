import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddinternComponent } from './addintern.component';

describe('AddinternComponent', () => {
  let component: AddinternComponent;
  let fixture: ComponentFixture<AddinternComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddinternComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddinternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
