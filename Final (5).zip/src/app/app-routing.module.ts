import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';

import { LoginComponent } from './login/login.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AdduserComponent } from './adduser/adduser.component';
import { ModifyuserComponent } from './modifyuser/modifyuser.component';
import { ListuserComponent } from './listuser/listuser.component';
import { AddinternComponent } from './addintern/addintern.component';
import { UploaduserComponent } from './uploaduser/uploaduser.component';
import { InternlistComponent } from './internlist/internlist.component';
import { LeaveRequestComponent } from './leave-request/leave-request.component';
import { LeaveHistoryComponent } from './leave-history/leave-history.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';
import { ModifyinternComponent } from './modifyintern/modifyintern.component';
import { WeekendworkrequestComponent } from './weekendworkrequest/weekendworkrequest.component';
import { WeekendworkhistoryComponent } from './weekendworkhistory/weekendworkhistory.component';
import { WeekendworkapprovalComponent } from './weekendworkapproval/weekendworkapproval.component';
import { FirstpasswordchangeComponent } from './firstpasswordchange/firstpasswordchange.component';
import { ManageseatComponent } from './manageseat/manageseat.component';
import { ManageassetComponent } from './manageasset/manageasset.component';
import { AllocateSeatComponent } from './allocate-seat/allocate-seat.component';
import { AllocateAssetComponent } from './allocate-asset/allocate-asset.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ListprojectComponent } from './listproject/listproject.component';
import { AllocatedDetailsComponent } from './allocated-details/allocated-details.component';
import { ReferralComponent } from './referral/referral.component';
import { ReferrallistComponent } from './referrallist/referrallist.component';
import { RequestCertificateComponent } from './request-certificate/request-certificate.component';
import { ViewCertificationRequestComponent } from './view-certification-request/view-certification-request.component';
import { UpdateProjectComponent } from './update-project/update-project.component';
import { ModifyreferralComponent } from './modifyreferral/modifyreferral.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'uploaduser', canActivate: [AuthGuard], component: UploaduserComponent },
  { path: 'addintern', canActivate: [AuthGuard], component: AddinternComponent },
  { path: 'modifyintern/:id', canActivate: [AuthGuard], component: ModifyinternComponent },
  { path: 'listuser', canActivate: [AuthGuard], component: ListuserComponent },
  { path: 'login', component: LoginComponent, runGuardsAndResolvers: 'always' },
  { path: 'home', canActivate: [AuthGuard], component: HomepageComponent },
  { path: 'leave-request', canActivate: [AuthGuard], component: LeaveRequestComponent },
  { path: 'leave-history', canActivate: [AuthGuard], component: LeaveHistoryComponent },
  { path: 'leave-approval', canActivate: [AuthGuard], component: LeaveApprovalComponent },
  { path: 'firstpasswordchange', canActivate: [AuthGuard], component: FirstpasswordchangeComponent },
  { path: 'adduser', canActivate: [AuthGuard], component: AdduserComponent },
  { path: 'modifyuser/:id', canActivate: [AuthGuard], component: ModifyuserComponent },
  { path: 'modifyuser', canActivate: [AuthGuard], component: ModifyuserComponent },
  { path: 'internlist', canActivate: [AuthGuard], component: InternlistComponent },
  { path: 'weekendworkrequest', canActivate: [AuthGuard], component: WeekendworkrequestComponent },
  { path: 'weekendworkhistory', canActivate: [AuthGuard], component: WeekendworkhistoryComponent },
  { path: 'weekendworkapproval', canActivate: [AuthGuard], component: WeekendworkapprovalComponent },
  { path: 'manageseat', canActivate: [AuthGuard], component: ManageseatComponent },
  { path: 'manageasset', canActivate: [AuthGuard], component: ManageassetComponent },
  { path: 'allocateseat', canActivate: [AuthGuard], component: AllocateSeatComponent },
  { path: 'allocateasset', canActivate: [AuthGuard], component: AllocateAssetComponent },
  { path: 'addproject', component: AddProjectComponent },
  { path: 'listproject', component: ListprojectComponent },
  { path: 'allocateddetails', component: AllocatedDetailsComponent },
  { path: 'referral', component: ReferralComponent },
  { path: 'referrallist', component: ReferrallistComponent },
  { path: 'request-certificate', component: RequestCertificateComponent },
  { path: 'modifyreferral/:id', component: ModifyreferralComponent },
  { path: 'view-certification-request', component: ViewCertificationRequestComponent },
  { path: 'update-project/:projectId', component: UpdateProjectComponent },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [
    CommonModule
    , RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
