import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocateSeatComponent } from './allocate-seat.component';

describe('AllocateSeatComponent', () => {
  let component: AllocateSeatComponent;
  let fixture: ComponentFixture<AllocateSeatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocateSeatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocateSeatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
