import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-allocate-seat',
  templateUrl: './allocate-seat.component.html',
  styleUrls: ['./allocate-seat.component.css']
})
export class AllocateSeatComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  seatId: any;
  internId: any;
  result: any;
  internIdError = false;
  seatIdError = false;
  seatValues: any = [];
  interns: any = [];
  seats: any = [];
  currentPage = 1;
  searchTxt: any;
  itemArr: any = [];
  empIdArr: any = [];

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.showTable();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  showTable() {

    const getAllAssignedSeatDetailsSub = this._http.get(this.baseUrl + '/getAllAssignedSeatDetails/').subscribe(data => {
      this.result = data;
    }, (err) => {
      console.log('Error Occured in listing assigned seats');
    }
    );
    this.subscriptions.add(getAllAssignedSeatDetailsSub);

    const getAllNonAssignedSeatDetailsSub = this._http.get(this.baseUrl + '/getAllNonAssignedSeatDetails/').subscribe(dataDropDown => {
      this.seats = dataDropDown;
    }, (err) => {
      console.log('Error Occured in listing non assigned seats');
    }
    );
    this.subscriptions.add(getAllNonAssignedSeatDetailsSub);

    const getAllInternsUnAssignedSub = this._http.get(this.baseUrl + '/getAllInternsUnAssigned/').subscribe(dataDropDown => {
      this.interns = dataDropDown;
    }, (err) => {
      console.log('Error Occured in listing non assigned interns');
    }
    );
    this.subscriptions.add(getAllInternsUnAssignedSub);

  }

  checkbox(item: any) {
    if (this.itemArr.find(x => x === item)) {
      this.itemArr.splice(this.itemArr.indexOf(item), 1);
    } else {
      this.itemArr.push(item);
    }
  }


  allocateSeat(formsValue, formStatus) {

    this.internIdError = true;
    this.seatIdError = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        })
      };

      const allocateSeatSub = this._http.put(this.baseUrl + '/allocateSeat/' + formsValue.seatId + '/' + formsValue.internId, httpOptions)
        .subscribe(data => {
          alert('Successfully alloacated seat');
          this.showTable();
          this.reset();
        }, (err) => {
          console.log('Error occurred in allocating seat');
        });
      this.subscriptions.add(allocateSeatSub);
    }

  }

  deAllocateSeat() {

    if (this.itemArr.length <= 0) {
      alert('Please select atleast one record');
    } else if (this.itemArr.length > 0) {
      for (let i = 0; i < this.itemArr.length; i++) {
        this.empIdArr.push(this.itemArr[i].empId);
      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        })
      };

      const deAllocateSeatSub = this._http.put(this.baseUrl + '/deAllocateSeat/' + this.empIdArr, httpOptions)
        .subscribe(data => {
          alert('Successfully de-allocated seat');
        }, (err) => {
          console.log('Error occurred in de-allocating seat');
        }, () => {
          this.showTable();
          this.itemArr = [];
          this.empIdArr = [];

        });

      this.subscriptions.add(deAllocateSeatSub);

    }
  }

  back() {
    this.router.navigate(['home']);
  }

  reset() {
    this.seatId = null;
    this.internId = null;
    this.internIdError = false;
    this.seatIdError = false;
  }

}




