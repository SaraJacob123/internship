import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyinternComponent } from './modifyintern.component';

describe('ModifyinternComponent', () => {
  let component: ModifyinternComponent;
  let fixture: ComponentFixture<ModifyinternComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyinternComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyinternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
