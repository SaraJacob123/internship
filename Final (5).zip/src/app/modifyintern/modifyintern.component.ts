import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-modifyintern',
  templateUrl: './modifyintern.component.html',
  styleUrls: ['./modifyintern.component.css']
})
export class ModifyinternComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  email: any;
  firstname: any;
  lastname: any;
  cid: any;
  id: any;
  allDropDownValues: any = [];
  skills: any = [];
  branches: any = [];
  selectedSkills: any = [];
  proficiency: any;
  preferred: any;
  skill: any;
  duration: any;
  startDt: any;
  endDt: any;
  mobile: any;
  accessCardNo: any;
  qualification: any;
  branch: any;
  specialization: any;
  college: any;
  cEmailId: any;
  Backpaper: any;
  CGPA: any;
  Year: any;
  pdfFile: any;
  selskillid: any;
  selPro: any;
  selPref: any;
  selproficiency: any;
  selpreferred: any;
  qualifications: any = [];
  result: any;
  ongoing: any;
  internskills: any;
  location: any;
  comments: any;
  durClearErr = false;
  sDateClearErr = false;
  eDateClearErr = false;
  accessnoClearErr = false;
  mobileclearErr = false;
  qualificationSelErr = false;
  BranchSelErr = false;
  OngoingClearErr = false;
  CollegeClearErr = false;
  coemailErr = false;
  backpapervalidErr = false;
  cgpavalidErr = false;
  YofErr = false;
  collegelettervalidErr = false;
  error: any;
  selSkillIdx;
  invalidDateErr = false;
  locationErr = false;
  commentErr = false;
  locationvalidErr = false;
  typeofUser: any;
  idOfIntern: any;
  existingIntern: boolean;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router,
    private _http: HttpClient,
    private _route: ActivatedRoute,
    private _authService: AuthenticationService) { }

  ngOnInit() {

    this.typeofUser = this._authService.getTypeofUser();
    this._route.paramMap.switchMap((params: ParamMap) => this.id = params.get('id')).subscribe();

    if (this.id === '' || this.typeofUser === 'EXISTING_INTERN') {
      this.existingIntern = true;
      this.id = this._authService.getLoggedInuserId();
    }

    const getAllOptionsSub = this._http.get(this.baseUrl + '/getAllOptions/')
      .subscribe(dataDropDown => {
        this.allDropDownValues = dataDropDown;
        for (const value of this.allDropDownValues) {
          if (value.optionType === 'skill') {
            this.skills.push({ 'skillId': value.optionCode, 'description': value.optionDesc });
          } else if (value.optionType === 'qualification') {
            this.qualifications.push({ 'qualificationId': value.optionCode, 'description': value.optionDesc });
          } else if (value.optionType === 'branch') {
            this.branches.push({ 'branchId': value.optionCode, 'description': value.optionDesc });
          }
        }
      }, (err) => {
        console.log('Error occurred in getting drop down values');
      });
    this.subscriptions.add(getAllOptionsSub);

    const getInternSub = this._http.get(this.baseUrl + '/getIntern/' + this.id, this.httpOptions).subscribe(data => {
      this.result = data;
      this.firstname = this.result.firstName;
      this.lastname = this.result.lastName;
      this.email = this.result.email;
      this.cid = this.result.empId;
      this.duration = this.result.duration;
      this.mobile = this.result.mobile;
      this.accessCardNo = this.result.accessCardNo;
      this.qualification = this.result.qualificationId;
      this.branch = this.result.branchId;
      this.startDt = this.result.startDate;
      this.endDt = this.result.endDate;
      this.Backpaper = this.result.backPaper;
      this.CGPA = this.result.cgpa;
      this.Year = this.result.yearOfPass;
      this.ongoing = this.result.ongoing;
      this.college = this.result.college;
      this.cEmailId = this.result.coordinatorEmail;
      this.location = this.result.location;
      this.comments = this.result.comments;
    },
      error => this.error = error
    );
    this.subscriptions.add(getInternSub);

    const getInternSkillSub = this._http.get(this.baseUrl + '/getInternSkill/' + this.id).subscribe(data => {
      this.selectedSkills = data;
    },
      error => this.error = error
    );
    this.subscriptions.add(getInternSkillSub);

  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  setOnGoing(onGoing: any) {
    this.ongoing = onGoing;
  }

  back() {

    if (this.typeofUser === 'EXISTING_INTERN') {
      this.router.navigate(['home']);
    } else {
      this.router.navigate(['internlist']);
    }
  }

  fileChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      const file: File = fileList[0];
      this.pdfFile = file;
      this.collegelettervalidErr = false;
    } else {
      this.pdfFile = undefined;
      this.collegelettervalidErr = true;
    }
  }

  updateIntern(formValue: any, formStatus: any) {

    this.durClearErr = true;
    this.sDateClearErr = true;
    this.eDateClearErr = true;
    this.accessnoClearErr = true;
    this.mobileclearErr = true;
    this.qualificationSelErr = true;
    this.BranchSelErr = true;
    this.OngoingClearErr = true;
    this.CollegeClearErr = true;
    this.locationvalidErr = true;
    this.coemailErr = true;
    this.backpapervalidErr = true;
    this.cgpavalidErr = true;
    this.YofErr = true;

    if (formValue.startDt > formValue.endDt) {
      this.invalidDateErr = true;
    } else {
      this.invalidDateErr = false;
    }

    if (this.pdfFile === undefined) {
      this.collegelettervalidErr = true;
    } else {
      this.collegelettervalidErr = false;
    }

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      let mainBody;
      if (this.typeofUser === 'ADMIN') {
        mainBody = JSON.stringify({
          'firstName': formValue.firstname,
          'lastName': formValue.lastname,
          'empId': formValue.cid,
          'duration': formValue.duration,
          'startDate': formValue.startDt,
          'endDate': formValue.endDt,
          'mobile': formValue.mobile,
          'accessCardNo': formValue.accessCardNo,
          'qualificationId': formValue.qualification,
          'branchId': formValue.branch,
          'college': formValue.college,
          'coordinatorEmail': formValue.cEmailId,
          'ongoing': formValue.ongoing,
          'approvalLetter': null,
          'backPaper': formValue.Backpaper,
          'cgpa': formValue.CGPA,
          'yearOfPass': formValue.Year,
          'location': formValue.location,
          'comments': formValue.comments
        });
      } else {
        mainBody = JSON.stringify({
          'firstName': this.firstname,
          'lastName': this.lastname,
          'empId': this.cid,
          'duration': this.duration,
          'startDate': this.startDt,
          'endDate': this.endDt,
          'mobile': formValue.mobile,
          'accessCardNo': this.accessCardNo,
          'qualificationId': this.qualification,
          'branchId': this.branch,
          'college': this.college,
          'coordinatorEmail': this.cEmailId,
          'ongoing': this.ongoing,
          'approvalLetter': null,
          'backPaper': this.Backpaper,
          'cgpa': this.CGPA,
          'yearOfPass': this.Year,
          'location': this.location,
          'comments': formValue.comments
        });
      }

      const updateInternSub = this._http.put(this.baseUrl + '/updateIntern/', mainBody, this.httpOptions)
        .subscribe(data => {

          if (this.pdfFile !== undefined) {
            const formData = new FormData();
            formData.append('empId', formValue.cid);
            formData.append('file', this.pdfFile);

            const uploadLetterSub = this._http.post(this.baseUrl + '/uploadLetter/file', formData, { responseType: 'text' })
              .subscribe(() => {
                console.log('File uploaded successfully');

              }, (err) => {
                console.log('Error occured in uploading file : ' + err.message);
              });

            this.subscriptions.add(uploadLetterSub);

          }

          const deleteInternSkillSub = this._http.delete(this.baseUrl + '/deleteInternSkill/' + formValue.cid, this.httpOptions)
            .subscribe(() => {
              console.log('Deleted stored intern skills');
              for (let i = 0; i < this.selectedSkills.length; i++) {
                this.selskillid = this.selectedSkills[i].skillId;
                this.selPro = this.selectedSkills[i].proficiency;
                this.selPref = this.selectedSkills[i].preferred;

                if (this.selPro === 'Expert') {
                  this.selproficiency = 'E';
                } else if (this.selPro === 'Intermediate') {
                  this.selproficiency = 'I';
                } else if (this.selPro === 'Advanced') {
                  this.selproficiency = 'A';
                } else {
                  this.selproficiency = 'B';
                }

                if (this.selPref === 'Yes') {
                  this.selpreferred = 'Y';
                } else {
                  this.selpreferred = 'N';
                }

                let skillBody;
                if (this.typeofUser === 'ADMIN') {
                  skillBody = JSON.stringify({
                    'skillId': this.selskillid,
                    'proficiency': this.selproficiency,
                    'preferred': this.selpreferred,
                    'other': null,
                    'internId': this.id
                  });
                } else {
                  skillBody = JSON.stringify({
                    'skillId': this.selskillid,
                    'proficiency': this.selproficiency,
                    'preferred': this.selpreferred,
                    'other': null,
                    'internId': this.cid
                  });
                }

                const addInternSkillSub = this._http.post(this.baseUrl + '/addInternSkill/', skillBody, this.httpOptions)
                  .subscribe(() => {
                    console.log('Skill added successfully');
                  }, (err) => {
                    console.log('Error occured in adding skill');
                  });
                this.subscriptions.add(addInternSkillSub);
              }
              alert('Intern updated successfully');
            }, (err) => {
              console.log('Intern skill could not be deleted');
            }
            );
          this.subscriptions.add(deleteInternSkillSub);

        }, (err) => {
          console.log(err.message);
          alert('Error occurred in updating intern');
        }
        );
      this.subscriptions.add(updateInternSub);

    }
  }

  addSkill(formVal: any, skillName: any) {

    if (this.selectedSkills.findIndex(x => x.skillId === formVal.skill) < 0) {
      this.selectedSkills.push({
        skillId: formVal.skill,
        skill: skillName,
        proficiency: formVal.proficiency,
        preferred: formVal.preferred
      });
    } else {
      alert(skillName + ' is already added to selected skills');
    }
    this.proficiency = '';
    this.preferred = '';
    this.skill = '';

  }

  deleteSkill(skillId: any, skill: any, index: number) {
    this.selectedSkills.splice(index, 1);
    this.skill = '';
  }

  reset() {
    this.duration = '';
    this.startDt = '';
    this.endDt = '';
    this.mobile = '';
    this.accessCardNo = '';
    this.qualification = '';
    this.specialization = '';
    this.ongoing = '';
    this.cEmailId = '';
    this.Backpaper = '';
    this.CGPA = '';
    this.Year = '';
    this.college = '';
    this.location = '';
    this.comments = '';
    this.durClearErr = false;
    this.sDateClearErr = false;
    this.eDateClearErr = false;
    this.accessnoClearErr = false;
    this.mobileclearErr = false;
    this.qualificationSelErr = false;
    this.BranchSelErr = false;
    this.OngoingClearErr = false;
    this.CollegeClearErr = false;
    this.coemailErr = false;
    this.backpapervalidErr = false;
    this.cgpavalidErr = false;
    this.YofErr = false;
    this.collegelettervalidErr = false;
    this.locationvalidErr = false;
  }

}


