import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCertificationRequestComponent } from './view-certification-request.component';

describe('ViewCertificationRequestComponent', () => {
  let component: ViewCertificationRequestComponent;
  let fixture: ComponentFixture<ViewCertificationRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCertificationRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCertificationRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
