
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-view-certification-request',
  templateUrl: './view-certification-request.component.html',
  styleUrls: ['./view-certification-request.component.css']
})
export class ViewCertificationRequestComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any = [];
  currentPage = 1;
  searchText: any;

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {

    const listCertificateRequestSub = this._http.get(this.baseUrl + '//').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in Listing certificate requests');
    });
    this.subscriptions.add(listCertificateRequestSub);

  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  back() {
    this.router.navigate(['home']);
  }

}
