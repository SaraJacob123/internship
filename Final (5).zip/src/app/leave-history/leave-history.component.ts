import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-leave-history',
  templateUrl: './leave-history.component.html',
  styleUrls: ['./leave-history.component.css']
})
export class LeaveHistoryComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  currentPage = 1;
  result: any = [];
  cid: any;
  startDt: any;
  endDt: any;
  loggedinUser: any;
  loggedInternId: any;
  showUser: boolean;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };
  constructor(private router: Router, private _http: HttpClient, private _authService: AuthenticationService) { }

  ngOnInit() {

    this.loggedinUser = this._authService.getuser();
    this.loggedInternId = this._authService.getLoggedInuserId();

    if (this.loggedinUser === 'I') {

      this.showUser = true;

      const body = JSON.stringify({
        'internId': this.loggedInternId
      });

      const leaveHistorySub = this._http.post(this.baseUrl + '/leaveHistory/', body, this.httpOptions).subscribe(data => {
        this.result = data;
      }, (err) => {
        console.log('Error occurred in getting  leave requests');
      });
      this.subscriptions.add(leaveHistorySub);

    } else if (this.loggedinUser === 'E') {

      const body = JSON.stringify({
        'internId': 'admin'
      });

      const leaveHistorySub = this._http.post(this.baseUrl + '/leaveHistory/', body, this.httpOptions).subscribe(data => {
        this.result = data;
      }, (err) => {
        console.log('Error occurred in getting all leave requests');
      });
      this.subscriptions.add(leaveHistorySub);

    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  back() {
    this.router.navigate(['home']);
  }

  reset() {
    this.cid = '';
    this.startDt = '';
    this.endDt = '';
  }

}
