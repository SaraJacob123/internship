import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomepageComponent } from './homepage/homepage.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdduserComponent } from './adduser/adduser.component';
import { ModifyuserComponent } from './modifyuser/modifyuser.component';
import { ListuserComponent } from './listuser/listuser.component';
import { AddinternComponent } from './addintern/addintern.component';
import { UploaduserComponent } from './uploaduser/uploaduser.component';
import { InternlistComponent } from './internlist/internlist.component';
import { LeaveRequestComponent } from './leave-request/leave-request.component';
import { LeaveHistoryComponent } from './leave-history/leave-history.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';
import { ModifyinternComponent } from './modifyintern/modifyintern.component';
import { WeekendworkrequestComponent } from './weekendworkrequest/weekendworkrequest.component';
import { WeekendworkhistoryComponent } from './weekendworkhistory/weekendworkhistory.component';
import { WeekendworkapprovalComponent } from './weekendworkapproval/weekendworkapproval.component';
import { FirstpasswordchangeComponent } from './firstpasswordchange/firstpasswordchange.component';
import { ManageseatComponent } from './manageseat/manageseat.component';
import { ManageassetComponent } from './manageasset/manageasset.component';
import { AllocateSeatComponent } from './allocate-seat/allocate-seat.component';
import { AllocateAssetComponent } from './allocate-asset/allocate-asset.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ListprojectComponent } from './listproject/listproject.component';
import { AllocatedDetailsComponent } from './allocated-details/allocated-details.component';
import { ReferralComponent } from './referral/referral.component';
import { ViewCertificationRequestComponent } from './view-certification-request/view-certification-request.component';
import { RequestCertificateComponent } from './request-certificate/request-certificate.component';
import { UpdateProjectComponent } from './update-project/update-project.component';

import { AuthGuard } from './auth.guard';
import { AuthenticationService } from './authentication.service';

import { SearchPipe } from './pipes/search.pipe';
import { LeaveStatusSearchPipe } from './pipes/leave-status-search.pipe';
import { WeekendStatusSearchPipe } from './pipes/weekend-status-search.pipe';
import { LeaveDateSearchPipe } from './pipes/leave-date-search.pipe';
import { WeekendDateSearchPipe } from './pipes/weekend-date-search.pipe';
import { HistorySearchPipe } from './pipes/history-search.pipe';
import { StatusSearchPipe } from './pipes/status-search.pipe';
import { AssetSearchPipe } from './pipes/assetSearch.pipe';
import { SeatSearchPipe } from './pipes/seatSearch.pipe';
import { ReferrallistComponent } from './referrallist/referrallist.component';
import { ModifyreferralComponent } from './modifyreferral/modifyreferral.component';
import { ReferralSearchPipe } from './pipes/referral-search.pipe';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomepageComponent,
    HeaderComponent,
    FooterComponent,
    AdduserComponent,
    ModifyuserComponent,
    ListuserComponent,
    AddinternComponent,
    UploaduserComponent,
    InternlistComponent,
    LeaveApprovalComponent,
    LeaveHistoryComponent,
    LeaveRequestComponent,
    SearchPipe,
    LeaveStatusSearchPipe,
    WeekendStatusSearchPipe,
    LeaveDateSearchPipe,
    WeekendDateSearchPipe,
    HistorySearchPipe,
    StatusSearchPipe,
    AssetSearchPipe,
    SeatSearchPipe,
    ModifyinternComponent,
    WeekendworkrequestComponent,
    WeekendworkhistoryComponent,
    WeekendworkapprovalComponent,
    FirstpasswordchangeComponent,
    ManageseatComponent,
    ManageassetComponent,
    AllocateSeatComponent,
    AllocateAssetComponent,
    AddProjectComponent,
    ListprojectComponent,
    AllocatedDetailsComponent,
    ReferralComponent,
    ViewCertificationRequestComponent,
    RequestCertificateComponent,
    UpdateProjectComponent,
    ReferrallistComponent,
    ModifyreferralComponent,
    ReferralSearchPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [AuthenticationService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
