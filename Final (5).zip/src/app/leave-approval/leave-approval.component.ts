import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-leave-approval',
  templateUrl: './leave-approval.component.html',
  styleUrls: ['./leave-approval.component.css']
})
export class LeaveApprovalComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any;
  currentPage = 1;
  cid: any;
  startDt: any;
  endDt: any;
  comments: any;
  itemArr: any = [];
  commentTypeErr = false;
  adminfirstName: any;
  adminlastName: any;
  approvedBy: any;
  statusSrch: any;
  searchTxt: any;
  requestIds: any = [];
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router, private _http: HttpClient, private _authService: AuthenticationService) {
  }

  ngOnInit() {
    this.getAllRequests();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  getAllRequests() {
    this.adminfirstName = this._authService.getFirstName();
    this.adminlastName = this._authService.getLastName();
    this.approvedBy = this.adminfirstName + this.adminlastName;

    const getAllLeaveRequestSub = this._http.get(this.baseUrl + '/getAllLeaveRequest/').subscribe(data => {
      this.result = data;
    }, (err) => {
      console.log('Error occurred in getting all leave requests');
    });

    this.subscriptions.add(getAllLeaveRequestSub);
  }

  checkbox(item: any) {
    if (this.itemArr.find(x => x === item)) {
      this.itemArr.splice(this.itemArr.indexOf(item), 1);
    } else {
      this.itemArr.push(item);
    }
  }

  approveLeave(formValue: any, formStatus: any) {

    this.commentTypeErr = true;

    if (!formStatus) {
      alert('Please enter comments');
    } else if (this.itemArr.length <= 0) {
      alert('Please select atleast one record');
    } else if (this.itemArr.length > 0) {
      for (let i = 0; i < this.itemArr.length; i++) {
        this.requestIds.push(this.itemArr[i].leaveRequest.requestId);
      }
      const body = JSON.stringify({
        'approvedBy': this.approvedBy,
        'commentsMgr': formValue.comments,
      });

      const leaveApprovalSub = this._http.put(this.baseUrl + '/LeaveApproval/' + this.requestIds, body, this.httpOptions)

        .subscribe(data => {
          alert('Leave Request is Approved');
          this.getAllRequests();
        }, (err) => {
          console.log('Error occured in approve. ' + err.message);
        }, () => {
          this.itemArr = [];
          this.requestIds = [];
          this.comments = '';
          this.commentTypeErr = false;
        });
      this.subscriptions.add(leaveApprovalSub);
    }

  }

  rejectLeave(formValue: any, formStatus: any) {

    this.commentTypeErr = true;

    if (!formStatus) {
      alert('Please enter comments');
    } else if (this.itemArr.length <= 0) {
      alert('Please select atleast one record');
    } else if (this.itemArr.length > 0) {
      for (let i = 0; i < this.itemArr.length; i++) {
        this.requestIds.push(this.itemArr[i].leaveRequest.requestId);
      }
      const body = JSON.stringify({
        'approvedBy': this.approvedBy,
        'commentsMgr': formValue.comments,
      });

      const leaveRejectSub = this._http.put(this.baseUrl + '/LeaveReject/' + this.requestIds, body, this.httpOptions).subscribe(data => {
        alert('Leave request is rejected');
        this.getAllRequests();
      }, (err) => {
        console.log('Error occured in reject. ' + err.message);
      }, () => {
        this.itemArr = [];
        this.requestIds = [];
        this.comments = '';
        this.commentTypeErr = false;
      });
      this.subscriptions.add(leaveRejectSub);
    }

  }

  back() {
    this.router.navigate(['home']);
  }

  reset() {
    this.cid = '';
    this.startDt = '';
    this.endDt = '';
    this.comments = '';
    this.statusSrch = '';
    this.searchTxt = '';
  }

}


