import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageseatComponent } from './manageseat.component';

describe('ManageseatComponent', () => {
  let component: ManageseatComponent;
  let fixture: ComponentFixture<ManageseatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageseatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageseatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 