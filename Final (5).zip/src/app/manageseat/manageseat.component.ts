import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-manageseat',
  templateUrl: './manageseat.component.html',
  styleUrls: ['./manageseat.component.css']
})
export class ManageseatComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  seatId: any;
  systmId: any;
  location: any;
  searchTxt: any;
  seatIdErr = false;
  systmIdErr = false;
  locErr = false;
  result: any = [];
  currentPage = 1;
  isEditMode = false;
  result1: any = [];

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.showTable();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  showTable() {
    const getAllSeatSub = this._http.get(this.baseUrl + '/getAllSeat/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing Seat');
    });
    this.subscriptions.add(getAllSeatSub);
  }

  addSeat(formsValue, formStatus) {    

    this.seatIdErr = true;
    this.systmIdErr = true;
    this.locErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      const matchProp = this.checkDuplicate(this.result, formsValue.seatId, formsValue.systmId, formsValue.location);
      if(matchProp === 'Seat') {
        alert('Seat with ID: ' + formsValue.seatId + ' has been already added in ' + formsValue.location);
      } else if(matchProp === 'System') {
        alert('System with ID: ' + formsValue.systmId + ' has been already added in ' + formsValue.location);
      } else {
        const body = JSON.stringify({
          'seatId': formsValue.seatId,
          'systemId': formsValue.systmId,
          'location': formsValue.location
        });

        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
          )
        };

        const addSeatSub = this._http.post(this.baseUrl + '/addSeat/', body, httpOptions)
          .subscribe(data => {
            if (data === null) {
              alert('Error occured in adding seat');
            } else {
              alert('Successfully Added seat');
            }
            this.reset();
            this.showTable();
          }, (err) => console.log('Error occurred in adding seat'));
        this.subscriptions.add(addSeatSub);
      }
    }

  }

  deleteFieldValue(id) {
    const seatAssignedCheckSub = this._http.get(this.baseUrl + '/seatAssignedCheck/' + id.toString()).subscribe(data => {
      this.result1 = data;
      if (this.result1.empId === null || this.result1.empId === undefined || this.result1.empId === 'null') {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'text/plain',
            'Access-Control-Allow-Origin': '*'
          })
        };
        const res = confirm('Are you sure, you want to delete?');
        if (res) {
          const deleteSeatSub = this._http.delete(this.baseUrl + '/deleteSeat/' + id.toString(), httpOptions).subscribe(() => { });
          this.subscriptions.add(deleteSeatSub);
          this.result = this.result.filter(item => item.seatId !== id);
          this.reset();
        }
      } else {
        alert('Seat with id: ' + id + ' has been already allocated and in use. Kindly deallocate it before deleting.');
      }
    }, err => {
      console.log('Error Occured in deleting Seat');
    });
    this.subscriptions.add(seatAssignedCheckSub);

  }

  updateSeat(formsValue, formStatus) {

    this.seatIdErr = true;
    this.systmIdErr = true;
    this.locErr = true;

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
      const matchProp = this.checkDuplicate(this.result, '', formsValue.systmId, formsValue.location);
      if(matchProp === 'System') {
        alert('System with ID: ' + formsValue.systmId + ' has been already allocated to a different seat in ' + formsValue.location);
      } else {
        const body = JSON.stringify({
          'seatId': formsValue.seatId,
          'systemId': formsValue.systmId,
          'location': formsValue.location
        });
  
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
          )
        };
  
        const updateSeatSub = this._http.put(this.baseUrl + '/updateSeat/', body, httpOptions)
          .subscribe(data => {
            alert('Successfully updated seat');
            this.reset();
            this.showTable();
            this.isEditMode = false;
          }, (err) => console.log('Error occurred in updating seat'));
        this.subscriptions.add(updateSeatSub);
      }
      
    }

  }

  checkDuplicate(JSON, seatId, systemId, location) {
    let hasMatch = false;
    let matchProp = '';
    for (let index = 0; index < JSON.length; ++index) {
      const item = JSON[index];
      if (item.seatId === seatId && item.location === location) {
        hasMatch = true;
        matchProp = 'Seat';
        break;
      }
      if (item.systemId === systemId && item.location === location) {
        hasMatch = true;
        matchProp = 'System';
        break;
      }
    }
    if (hasMatch) {
      return matchProp;
    } else {
      return '';
    }
  }


  modifySeat(id: any, sid: any, loc: any) {
    this.seatId = id;
    this.systmId = sid;
    this.location = loc;
    this.isEditMode = true;
  }

  reset() {
    this.seatId = '';
    this.systmId = '';
    this.location = '';
    this.searchTxt = '';
    this.seatIdErr = false;
    this.systmIdErr = false;
    this.locErr = false;
    this.isEditMode = false;
  }

  back() {
    this.router.navigate(['home']);
  }

}
