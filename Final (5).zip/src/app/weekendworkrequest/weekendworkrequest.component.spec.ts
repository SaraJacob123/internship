import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekendworkrequestComponent } from './weekendworkrequest.component';

describe('WeekendworkrequestComponent', () => {
  let component: WeekendworkrequestComponent;
  let fixture: ComponentFixture<WeekendworkrequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekendworkrequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekendworkrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
