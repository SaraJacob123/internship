import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-weekendworkrequest',
  templateUrl: './weekendworkrequest.component.html',
  styleUrls: ['./weekendworkrequest.component.css']
})
export class WeekendworkrequestComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  empID: any;
  startDt: any;
  endDt: any;
  duration: any;
  comments: any;
  durationcalc: any;
  sDateClearErr = false;
  eDateClearErr = false;
  invalidDateErr = false;
  commentTypeErr = false;

  constructor(private router: Router,
    private _http: HttpClient,
    private _authService: AuthenticationService) { }

  ngOnInit() {
    this.empID = this._authService.getLoggedInuserId();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  calcDuration() {

    if (this.invalidDateErr === true) {
      this.duration = '';
    }

    this.durationcalc = Date.parse(this.endDt) - Date.parse(this.startDt);

    const day = (this.durationcalc / 86400000) + 1;
    if (day > 0) {
      this.duration = day;
    } else {
      this.duration = '';
    }

  }

  weekendRequest(formVal, formStatus) {
    this.sDateClearErr = true;
    this.eDateClearErr = true;
    this.commentTypeErr = true;
    this.startDt = formVal.startDt;
    this.endDt = formVal.endDt;
    this.duration = formVal.duration;
    this.comments = formVal.comments;

    if (this.startDt > this.endDt) {
      this.invalidDateErr = true;
    } else {
      this.invalidDateErr = false;
    }

    if (!formStatus || this.invalidDateErr) {
      alert('Please fill the form with Required Data');
    } else {
      const body = JSON.stringify({
        'internId': this.empID,
        'fromDate': this.startDt,
        'toDate': this.endDt,
        'duration': this.duration,
        'commentsInt': this.comments,
        'approvedBy': ' '
      });
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };
      const addWeekendReqSub = this._http.post(this.baseUrl + '/addWeekendReq/', body, httpOptions)
        .subscribe(data => {
          alert('Weekend work Requested');
          this.reset();
        }, (err) => console.log('Error Occurred'));
      this.subscriptions.add(addWeekendReqSub);
    }
  }

  reset() {
    this.startDt = null;
    this.endDt = null;
    this.comments = '';
    this.duration = '';
    this.sDateClearErr = false;
    this.eDateClearErr = false;
    this.commentTypeErr = false;
    this.invalidDateErr = false;
  }

  back() {
    this.router.navigate(['home']);
  }

}
