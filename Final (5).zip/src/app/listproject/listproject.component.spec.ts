import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListprojectComponent } from './listproject.component';

describe('ListprojectComponent', () => {
  let component: ListprojectComponent;
  let fixture: ComponentFixture<ListprojectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListprojectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
