import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-listproject',
  templateUrl: './listproject.component.html',
  styleUrls: ['./listproject.component.css']
})
export class ListprojectComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any;
  Name: any;
  currentPage = 1;
  search: any;
  searchTxt: any;

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    const getAllProjectSub = this._http.get(this.baseUrl + '/getAllProjects/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing projects');
    });
    this.subscriptions.add(getAllProjectSub);
  }


  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  deleteFieldValue(id) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };
    const res = confirm('Are you sure, you want to delete?');
    if (res) {
      const deleteProjectSub = this._http.delete(this.baseUrl + '/deleteProject/' + id.toString(), httpOptions).subscribe(() => { });
      this.result = this.result.filter(item => item.projectID !== id);
      this.subscriptions.add(deleteProjectSub);
    }
  }
 back() {
    this.router.navigate(['home']);
  }
}
