import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';


@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  projectId: any;
  projectName: any;
  manager: any;
  architect: any;
  status: any;
  type: any;
  result: any;
  internId: any;
  firstName: any;
  lastName: any;
  startDt: any;
  endDt: any;
  skills: any;
  addedResources: any = [];
  allDropDownValues: any = [];
  managers: any = [];
  architects: any = [];
  actstartDt: any;
  actendDt: any;
  planstartDt: any;
  planendDt: any;
  actPoc: any;
  comments: any;
  httpOptions: any;
  description: any;
  pnameClearErr = false;
  managerClearErr = false;
  architectClearErr = false;
  viewData = false;
  asDateClearErr = false;
  aeDateClearErr = false;
  invalidADateErr = false;
  plansDateClearErr = false;
  planeDateClearErr = false;
  invalidPDateErr = false;
  statusClearErr = false;
  typeClearErr = false;
  pocClearErr = false;
  desTypeErr = false;
  selInternId:any;
  returnProjectId:any;
  intern:any;

  constructor(private _http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };
    this.internDetails();
    this.employeeDetails();
  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
  setType(type: any) {
    this.type = type;
  }

  internDetails() {
    const getAllInternsSub = this._http.get(this.baseUrl + '/getAllInternsForProjects/').subscribe(data => {
      this.result = data;
    }, err => {
      console.log('Error Occured in listing interns');
    });
    this.subscriptions.add(getAllInternsSub);
  }

  employeeDetails() {
    const getAllUserSub = this._http.get(this.baseUrl + '/getAllUser/')
      .subscribe(dataDropDown => {
        this.allDropDownValues = dataDropDown;


        for (const value of this.allDropDownValues) {
          if (value.userType === 'Employee') {
            this.managers.push({ 'empId': value.empId, 'firstName': value.firstName, 'lastName': value.lastName });
            this.architects.push({ 'empId': value.empId, 'firstName': value.firstName, 'lastName': value.lastName });
          }
        }

      });
    this.subscriptions.add(getAllUserSub);
  }

  onManagerChange(selectedManager: any) {
   this.manager = selectedManager;    
  }

  onArchitectChange(selectedArchitect: any) {
   this.architect = selectedArchitect;
  }

  saveProject(formValue: any, formStatus: any) {
    this.pnameClearErr = true;
    this.managerClearErr = true;
    this.architectClearErr = true;
    this.asDateClearErr = true;
    this.aeDateClearErr = true;
    this.plansDateClearErr = true;
    this.planeDateClearErr = true;
    this.statusClearErr = true;
    this.typeClearErr = true;
    this.pocClearErr = true;
    this.desTypeErr = true;
    

    if (formValue.actstartDt > formValue.actendDt) {
      this.invalidADateErr = true;
    } else {
      this.invalidADateErr = false;
    }

    if (formValue.planstartDt > formValue.planendDt) {
      this.invalidPDateErr = true;
    } else {
      this.invalidPDateErr = false;
    }

    if (!formStatus) {
      alert('Please fill the form with Required Data');
    } else {
        const projectBody = JSON.stringify({
       
        'projectName':formValue.projectName,
        'manager':this.manager.firstName + ' ' + this.manager.lastName,
        'managerID':this.manager.empId,
        'architect': this.architect.firstName + ' ' + this.architect.lastName,
        'architectID':this.architect.empId,
        'projectDesc':formValue.description,
        'plannedStartDate':formValue.planstartDt,
        'plannedEndDate':formValue.planendDt,
        'actualStartDate':formValue.actstartDt,
        'actualEndDate':formValue.actendDt,
        'projectStatus':formValue.status,
        'projectType':formValue.type,
        'comments':formValue.comments,
        'accountPOC':formValue.actPoc
        });
     const addProjectSub = this._http.post(this.baseUrl + '/addProject/', projectBody, this.httpOptions)
     .subscribe(data => {
        this.returnProjectId = data;
        console.log(this.returnProjectId);

     for (let i = 0; i < this.addedResources.length; i++) {
        this.selInternId = this.addedResources[i].internId;
       const addProjectInternSub = this._http.post(this.baseUrl + '/addProjectIntern/'+ this.selInternId + '/' + this.returnProjectId, this.httpOptions)
              .subscribe(() => {
                console.log('Intern added successfully');
              }, (err) => {
                console.log('Error occured in adding intern: ' + err.mssage);
              });
             this.subscriptions.add(addProjectInternSub);
     }
          alert('Assigning project successfully');
          this.reset();
        }, (err) => {
          console.log('Error occured in assigning Project: ' + err.message);
         });
     this.subscriptions.add(addProjectSub);
    }
   }

  deleteSelectedInterns(IntId :any,intern: any,index :number) {
      this.addedResources.splice(index, 1);
      this.intern = '';
  }

  addIntern(intId: any, fName: any, lName: any, sDate: any, eDate: any, skillsIntern: any) {
    if (this.addedResources.findIndex(x => x.internId === intId) < 0) {
      this.addedResources.push({
        internId: intId, firstName: fName, lastName: lName, startDate: sDate, endDate: eDate, skills: skillsIntern
      });
    } else {
      alert(fName + ' ' + lName + '' + ' is already selected');
    }
  }

  reset() {
    this.projectId = '';
    this.projectName = '';
    this.description = '';
    this.manager = '';
    this.architect = '';
    this.actstartDt = '';
    this.actendDt = '';
    this.planstartDt = '';
    this.planendDt = '';
    this.status = '';
    this.type = '';
    this.actPoc = '';
    this.comments = '';
  
    this.desTypeErr = false;
    this.pnameClearErr = false;
    this.managerClearErr = false;
    this.architectClearErr = false;
    this.asDateClearErr = false;
    this.aeDateClearErr = false;
    this.invalidADateErr = false;
    this.plansDateClearErr = false;
    this.planeDateClearErr = false;
    this.invalidPDateErr = false;
    this.statusClearErr = false;
    this.typeClearErr = false;
    this.pocClearErr = false;
    this.addedResources = [];
  }

  back() {
    this.router.navigate(['home']);
  }

}
