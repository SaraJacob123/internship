import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekendworkapprovalComponent } from './weekendworkapproval.component';

describe('WeekendworkapprovalComponent', () => {
  let component: WeekendworkapprovalComponent;
  let fixture: ComponentFixture<WeekendworkapprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekendworkapprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekendworkapprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
