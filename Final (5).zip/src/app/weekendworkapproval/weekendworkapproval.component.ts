import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-weekendworkapproval',
  templateUrl: './weekendworkapproval.component.html',
  styleUrls: ['./weekendworkapproval.component.css']
})
export class WeekendworkapprovalComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  result: any;
  currentPage = 1;
  cid: any;
  startDt: any;
  endDt: any;
  comments: any;
  itemArr: any = [];
  commentTypeErr = false;
  adminfirstName: any;
  adminlastName: any;
  approvedBy: any;
  requestIds: any = [];
  searchTxt: any;
  statusSrch: any;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router, private _http: HttpClient, private _authService: AuthenticationService) { }

  ngOnInit() {
    this.getAllRequests();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  getAllRequests() {
    this.adminfirstName = this._authService.getFirstName();
    this.adminlastName = this._authService.getLastName();
    this.approvedBy = this.adminfirstName + this.adminlastName;
    const getAllWeekendRequestSub = this._http.get(this.baseUrl + '/getAllWeekendRequest/').subscribe(data => {
      this.result = data;
    }, (err) => {
      console.log('Error occurred in getting all weekend requests');
    });
    this.subscriptions.add(getAllWeekendRequestSub);
  }

  checkbox(item: any) {
    if (this.itemArr.find(x => x === item)) {
      this.itemArr.splice(this.itemArr.indexOf(item), 1);
    } else {
      this.itemArr.push(item);
    }
  }

  approveWork(formValue: any, formStatus: any) {

    this.commentTypeErr = true;

    if (!formStatus) {
      alert('Please enter comments');
    } else if (this.itemArr.length <= 0) {
      alert('Please select atleast one record');
    } else if (this.itemArr.length > 0) {
      for (let i = 0; i < this.itemArr.length; i++) {
        this.requestIds.push(this.itemArr[i].weekEnd.requestId);
      }
      const body = JSON.stringify({
        'approvedBy': this.approvedBy,
        'commentsMgr': formValue.comments,
      });
      const weekendApprovalSub = this._http.put(this.baseUrl + '/weekendApproval/' + this.requestIds, body, this.httpOptions)
        .subscribe(data => {
          alert('Weekend work request is approved');
          this.getAllRequests();
        }, (err) => {
          console.log('Error occured in approve. ' + err.message);
        }, () => {
          this.itemArr = [];
          this.requestIds = [];
          this.comments = '';
          this.commentTypeErr = false;
        });
      this.subscriptions.add(weekendApprovalSub);
    }

  }

  rejectWork(formValue: any, formStatus: any) {

    this.commentTypeErr = true;

    if (!formStatus) {
      alert('Please enter comments');
    } else if (this.itemArr.length <= 0) {
      alert('Please select atleast one record');
    } else if (this.itemArr.length > 0) {
      for (let i = 0; i < this.itemArr.length; i++) {
        this.requestIds.push(this.itemArr[i].weekEnd.requestId);

      }
      const body = JSON.stringify({
        'approvedBy': this.approvedBy,
        'commentsMgr': formValue.comments,
      });
      const weekendRejectSub = this._http.put(this.baseUrl + '/weekendReject/' + this.requestIds, body, this.httpOptions)
        .subscribe(data => {
          alert('Weekend work request is rejected');
          this.getAllRequests();
        }, (err) => {
          console.log('Error occured in reject. ' + err.message);
        }, () => {
          this.itemArr = [];
          this.requestIds = [];
          this.comments = '';
          this.commentTypeErr = false;
        });
      this.subscriptions.add(weekendRejectSub);
    }

  }

  back() {
    this.router.navigate(['home']);
  }

  reset() {
    this.cid = '';
    this.startDt = '';
    this.endDt = '';
    this.comments = '';
    this.searchTxt = '';
    this.statusSrch = '';
  }

}

