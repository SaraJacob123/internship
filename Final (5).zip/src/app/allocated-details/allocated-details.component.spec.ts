import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocatedDetailsComponent } from './allocated-details.component';

describe('AllocatedDetailsComponent', () => {
  let component: AllocatedDetailsComponent;
  let fixture: ComponentFixture<AllocatedDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocatedDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocatedDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
