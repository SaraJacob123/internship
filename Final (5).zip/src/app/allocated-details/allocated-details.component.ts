import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-allocated-details',
  templateUrl: './allocated-details.component.html',
  styleUrls: ['./allocated-details.component.css']
})
export class AllocatedDetailsComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();
  baseUrl = environment.baseUrl;
  currentPage = 1;
  internId: any;
  result: any;
  resultSeat: any;
  seatId: any;
  systemId: any;
  constructor(private router: Router,
    private _http: HttpClient,
    private _authService: AuthenticationService) { }

  ngOnInit() {
    this.internId = this._authService.getLoggedInuserId();
    this.showSeatDetails();
    this.showAssetDetails();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  showSeatDetails() {
    const getAssignedSeatDetailsSub = this._http.get(this.baseUrl + '/getSeat/' + this.internId).subscribe(data => {
      this.resultSeat = data;
      this.seatId = this.resultSeat.seatId;
      this.systemId = this.resultSeat.systemId;
    }, (err) => {
      console.log('Error Occured getting seat');
    }
    );
    this.subscriptions.add(getAssignedSeatDetailsSub);
  }

  showAssetDetails() {
    const getAssignedAssetDetailsSub = this._http.get(this.baseUrl + '/getAsset/' + this.internId).subscribe(data => {
      this.result = data;
    }, (err) => {
      console.log('Error Occured getting seat');
    }
    );
    this.subscriptions.add(getAssignedAssetDetailsSub);
  }

}
