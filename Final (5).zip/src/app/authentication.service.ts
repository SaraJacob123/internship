import { Injectable, OnInit } from '@angular/core';

@Injectable()
export class AuthenticationService implements OnInit {

  private isLoggedIn: boolean;
  private email: string;
  private LoggedInUser: string;
  private user: string;
  private firstName: string;
  private lastName: string;
  private typeofUser: string;

  constructor() { }

  ngOnInit() {
    this.isLoggedIn = false;
  }

  setTypeofUser(typeofUser: string) {
    this.typeofUser = typeofUser;
  }

  getTypeofUser() {
    return this.typeofUser;
  }

  setUser(user: string) {
    this.user = user;
  }

  getuser() {
    return this.user;
  }

  setFirstName(fName: string) {
    this.firstName = fName;
  }

  getFirstName() {
    return this.firstName;
  }

  setLastName(lName: string) {
    this.lastName = lName;
  }

  getLastName() {
    return this.lastName;
  }

  setLoggedInUserId(LoggedInUser: string) {
    this.LoggedInUser = LoggedInUser;
  }

  getLoggedInuserId() {
    return this.LoggedInUser;
  }

  setLoggedInStatus(status: boolean) {
    this.isLoggedIn = status;
  }

  getLoggedInStatus(): boolean {
    return this.isLoggedIn;
  }

  setEmail(email: string) {
    this.email = email;
  }

  getEmail(): string {
    return this.email;
  }

}
