import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-uploaduser',
  templateUrl: './uploaduser.component.html',
  styleUrls: ['./uploaduser.component.css']
})
export class UploaduserComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  csvFile: File;
  collegelettervalidErr = false;

  constructor(private router: Router, private _http: HttpClient) { }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  back() {
    this.router.navigate(['home']);
  }

  fileChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      const file: File = fileList[0];
      this.csvFile = file;
      this.collegelettervalidErr = false;
    } else {
      this.csvFile = undefined;
      this.collegelettervalidErr = true;
    }
  }

  uploadUser() {
    if (this.csvFile === undefined) {
      this.collegelettervalidErr = true;
    } else {
      this.collegelettervalidErr = false;
      const formData = new FormData();
      formData.append('file', this.csvFile);

      const uploadFileSub = this._http.post(this.baseUrl + '/uploadFile', formData)
        .subscribe(data => {
          alert('Succesfully Uploaded User');
        }, (err) => console.log('Error occurred in uploading file'));
      this.subscriptions.add(uploadFileSub);
    }
  }
}
