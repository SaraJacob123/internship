import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/switchMap';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-modifyuser',
  templateUrl: './modifyuser.component.html',
  styleUrls: ['./modifyuser.component.css']
})
export class ModifyuserComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  userType: any;
  eId: any;
  firstName: any;
  lastName: any;
  email: any;
  password: any;
  hired: any;
  allocation: any;
  cpass: any;
  id: any;
  result: any;
  error: any;
  CheckedPassword = false;
  ECidError = false;
  fnameclearErr = false;
  lastNameErr = false;
  emailErr = false;
  passwordErr = false;
  cpassReqErr = false;
  cpassMatchErr = false;
  passPatternErr = false;

  constructor(private router: Router, private http: HttpClient, private _route: ActivatedRoute) { }

  ngOnInit() {

    this._route.paramMap.switchMap((params: ParamMap) => this.id = params.get('id')).subscribe();

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
      )
    };

    const getUserSub = this.http.get(this.baseUrl + '/getUser/' + this.id, httpOptions).subscribe(data => {
      this.result = data;
      this.eId = this.result.empId;
      this.firstName = this.result.firstName;
      this.lastName = this.result.lastName;
      this.hired = this.result.hired;
      this.allocation = this.result.allocation;
      this.email = this.result.email;
      this.password = this.result.password;
      this.cpass = this.result.password;
      this.userType = this.result.userType;
    },
      error => this.error = error
    );
    this.subscriptions.add(getUserSub);

  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  modifyUser(formsValue, formStatus) {
    if (formsValue.cpass === '') {
      this.cpassReqErr = true;
    } else {
      this.cpassReqErr = false;
    }

    if (formsValue.password === formsValue.cpass) {
      this.CheckedPassword = true;
      this.cpassMatchErr = false;
    } else {
      this.cpassMatchErr = true;
      this.CheckedPassword = false;
    }

    this.ECidError = true;
    this.fnameclearErr = true;
    this.lastNameErr = true;
    this.emailErr = true;
    this.passwordErr = true;
    this.passPatternErr = true;

    if (!formStatus || !this.CheckedPassword) {
      alert('Please fill the form with Required Data');
    } else {
      const body = JSON.stringify({
        'userType': formsValue.userType,
        'firstName': formsValue.firstName,
        'lastName': formsValue.lastName,
        'hired': formsValue.hired,
        'allocation': formsValue.allocation,
        'email': formsValue.email,
        'password': formsValue.password,
        'status': 'A'
      });

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };

      const updateUserSub = this.http.put(this.baseUrl + '/updateUser/' + this.id, body, httpOptions)
        .subscribe
        (data => {
          alert('Succesfully Updated User');
          this.router.navigate(['listuser']);
        }, (err) => console.log('error occurred'));
      this.subscriptions.add(updateUserSub);
    }
  }

  back() {
    this.router.navigate(['listuser']);
  }

}


