import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  email: any;
  typeofUser: any;
  loginDataObj: any;
  empID: any;
  usertype: any;
  firstName: any;
  lastName: any;
  forgotPassEmailErr = false;
  forgotPassPatternErr = false;
  isPasswordChanged: any;
  pass: any;

  baseUrl = environment.baseUrl;

  constructor(private router: Router,
    private http: HttpClient,
    private _authService: AuthenticationService) { }

  ngOnInit() { }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  loginUser(formsValue) {

    this.email = formsValue.email;
    const body = JSON.stringify({
      'email': formsValue.email,
      'password': formsValue.pass,
    });

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
      )
    };

    const loginSub = this.http.post(this.baseUrl + '/login/', body, httpOptions)
      .subscribe(data => {
        this.loginDataObj = Object.assign({}, data);
        this.typeofUser = this.loginDataObj.comments;

        if (this.loginDataObj.userDTO !== undefined && this.loginDataObj.userDTO !== null) {
          this.isPasswordChanged = this.loginDataObj.userDTO.is_password_changed;
          this.empID = this.loginDataObj.userDTO.empId;
          this.usertype = this.loginDataObj.userDTO.userType;
          this.firstName = this.loginDataObj.userDTO.firstName;
          this.lastName = this.loginDataObj.userDTO.lastName;
        }

        this._authService.setTypeofUser(this.typeofUser);
        this._authService.setUser(this.usertype);
        this._authService.setLoggedInUserId(this.empID);
        this._authService.setEmail(this.email);
        this._authService.setLoggedInStatus(true);
        this._authService.setFirstName(this.firstName);
        this._authService.setLastName(this.lastName);

        if (this.empID === '' || this.empID === undefined) {
          alert('Invalid User ID / Password');
          this.router.navigate(['login']);
        } else if (this.isPasswordChanged === 'Y') {
          this.router.navigate(['home']);
        } else {
          this.router.navigate(['firstpasswordchange']);
        }

      });
    this.subscriptions.add(loginSub);

  }

  forgotPassword(formsValue) {
    this.forgotPassEmailErr = true;
    this.forgotPassPatternErr = true;
    if (formsValue.email !== undefined) {
      this.email = formsValue.email;
      const httpOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
        )
      };
      const forgotPasswordSub = this.http.post(this.baseUrl + '/forgotPassword/' + this.email + '/', httpOption)
        .subscribe(data => {
          if (data === true) {
            alert('Password will be sent to your registered email ID');
          } else {
            alert('Email id not registered');
          }
        }, (err) => {
          alert('Email ID not registered. Please contact admin');
        }
        );
      this.subscriptions.add(forgotPasswordSub);
    }

  }
}
