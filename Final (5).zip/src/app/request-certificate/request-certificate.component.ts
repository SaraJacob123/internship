import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../authentication.service';
import { environment } from '../../environments/environment';
import { Subscription } from 'rxjs/Subscription';
@Component({
  selector: 'app-request-certificate',
  templateUrl: './request-certificate.component.html',
  styleUrls: ['./request-certificate.component.css']
})
export class RequestCertificateComponent implements OnInit, OnDestroy {

  private subscriptions = new Subscription();

  baseUrl = environment.baseUrl;
  currentPage = 1;
  loggedinUser: any;
  loggedInternId: any;
  showUser: boolean;
  internId:any;
  startDate: any;
  endDate: any;
  duration: any;
  projectName: any;
  projectSdate: any;
  projectEdate: any;
  result:any;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
    )
  };

  constructor(private router: Router, private _http: HttpClient, private _authService: AuthenticationService) { }

  ngOnInit() {
    this.internId = this._authService.getLoggedInuserId();
   
    this.loggedinUser = this._authService.getuser();
    this.loggedInternId = this._authService.getLoggedInuserId();
    if (this.loggedinUser === 'I') {
      this.showUser = true;
    } else if (this.loggedinUser === 'E') {
      this.showUser = false;
    }
    this.requestinternDetails();
  }



  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  requestinternDetails() {
    const getRequestCerificateSub = this._http.get(this.baseUrl + '/getIntern/' + this.internId).subscribe(data => {
      this.result = data;
      this.startDate = this.result.startDate;
      this.endDate = this.result.endDate;
      this.duration =this.result.duration;
      
    }, (err) => {
      console.log('Error Occured ');
    }
    );
    this.subscriptions.add(getRequestCerificateSub);
  }

 
  requestCerificate(formsValue) {
{

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*'
        })
      };

      const requestCertificateSub = this._http.put(this.baseUrl + '/requestCertificate/' + formsValue.internId , httpOptions)
        .subscribe(data => {
         
          alert('Successfully requested ');
         
         
        }, (err) => {
          console.log('Error occurred');
        });
      this.subscriptions.add(requestCertificateSub);
    }

  }

  back() {
    this.router.navigate(['home']);
  }

}
